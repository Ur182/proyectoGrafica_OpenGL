#!/usr/bin/env python3
"""Ajustes de colocación de la escena GLB del proyecto de fútbol.

Corrige el tamaño del carrito de alimentos, el recorrido del jugador, la
posición del árbitro, las cuatro esquinas, las porterías y las torres de luz.
Ejecutarlo una sola vez sobre la escena original, porque agrega nodos de
geometría nueva al GLB.
"""

from __future__ import annotations

import copy
import json
import math
import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GLB = ROOT / "assets" / "escenario.glb"
JSON_CHUNK = 0x4E4F534A
BIN_CHUNK = 0x004E4942


def read_glb(path: Path) -> tuple[dict, bytearray, list[tuple[int, bytes]]]:
    raw = path.read_bytes()
    if raw[:4] != b"glTF":
        raise ValueError(f"No es un GLB válido: {path}")
    chunks: list[tuple[int, bytes]] = []
    offset = 12
    while offset < len(raw):
        size, kind = struct.unpack_from("<II", raw, offset)
        offset += 8
        chunks.append((kind, raw[offset : offset + size]))
        offset += size
    doc = json.loads(next(data for kind, data in chunks if kind == JSON_CHUNK))
    binary = bytearray(next(data for kind, data in chunks if kind == BIN_CHUNK))
    return doc, binary, chunks


def write_glb(path: Path, doc: dict, binary: bytearray, chunks: list[tuple[int, bytes]]) -> None:
    json_data = json.dumps(doc, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    json_data += b" " * ((-len(json_data)) % 4)
    if len(binary) % 4:
        binary.extend(b"\0" * ((-len(binary)) % 4))
    output = bytearray(b"glTF")
    output.extend(struct.pack("<II", 2, 0))
    for kind, data in chunks:
        payload = json_data if kind == JSON_CHUNK else bytes(binary) if kind == BIN_CHUNK else data
        output.extend(struct.pack("<II", len(payload), kind))
        output.extend(payload)
    struct.pack_into("<I", output, 8, len(output))
    path.write_bytes(output)


def node_index(doc: dict, name: str) -> int:
    for i, node in enumerate(doc["nodes"]):
        if node.get("name") == name:
            return i
    raise KeyError(f"No se encontró el nodo {name!r}")


def add_box(doc: dict, name: str, mesh: int, pos: tuple[float, float, float],
            half: tuple[float, float, float]) -> int:
    node = {
        "name": name,
        "mesh": mesh,
        "translation": list(pos),
        "scale": list(half),
    }
    doc["nodes"].append(node)
    return len(doc["nodes"]) - 1


def set_position(node: dict, pos: tuple[float, float, float]) -> None:
    node["translation"] = list(pos)


def fix_player_path(doc: dict, binary: bytearray) -> None:
    """Lleva la carrera de x=-46..-64 a x=-36..-48 dentro del campo."""
    runner = node_index(doc, "Control | jugador carrera")
    set_position(doc["nodes"][runner], (-36.0, 0.0, 8.0))
    animation = next(a for a in doc["animations"]
                     if a.get("name") == "Control | jugador carreraAction.003")
    for channel in animation["channels"]:
        target = channel["target"]
        if target.get("node") != runner or target.get("path") != "translation":
            continue
        accessor = animation["samplers"][channel["sampler"]]["output"]
        acc = doc["accessors"][accessor]
        view = doc["bufferViews"][acc["bufferView"]]
        if acc["componentType"] != 5126 or acc["type"] != "VEC3":
            raise ValueError("El canal de posición del jugador no es VEC3 float")
        stride = view.get("byteStride", 12)
        start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
        xs: list[float] = []
        for i in range(acc["count"]):
            offset = start + i * stride
            x, y, z = struct.unpack_from("<3f", binary, offset)
            x = -36.0 + (x + 46.0) * (12.0 / 18.0)
            xs.append(x)
            struct.pack_into("<3f", binary, offset, x, y, z)
        acc["min"] = [min(xs), 0.0, 8.0]
        acc["max"] = [max(xs), 0.0, 8.0]
        break


def goal_children(doc: dict, prefix: str, frame_mesh: int, net_mesh: int) -> list[int]:
    children: list[int] = []

    def box(name: str, pos: tuple[float, float, float], half: tuple[float, float, float], net=False):
        children.append(add_box(doc, f"{prefix} | {name}", net_mesh if net else frame_mesh, pos, half))

    # Marco de tamaño reglamentario aproximado: 7.32 m de ancho y 2.44 m de alto.
    for side in (-1.0, 1.0):
        box(f"poste {side:+.0f}", (side * 3.66, 1.22, 0.0), (0.075, 1.22, 0.075))
        box(f"fondo lateral {side:+.0f}", (side * 3.66, 2.39, -1.0), (0.055, 0.055, 1.0))
        box(f"poste trasero {side:+.0f}", (side * 3.66, 1.2, -2.0), (0.055, 1.2, 0.055))
        # Retícula blanca en los laterales de la red.
        for y in (0.25, 0.65, 1.05, 1.45, 1.85, 2.25):
            box(f"red lateral {side:+.0f} horizontal {y:.2f}",
                (side * 3.62, y, -1.0), (0.018, 0.018, 0.92), net=True)
        for z in (-0.35, -1.0, -1.65):
            box(f"red lateral {side:+.0f} vertical {z:.2f}",
                (side * 3.62, 1.2, z), (0.018, 1.14, 0.018), net=True)
    box("travesaño", (0.0, 2.44, 0.0), (3.72, 0.075, 0.075))
    box("travesaño trasero", (0.0, 2.39, -2.0), (3.66, 0.055, 0.055))
    # Retícula de fondo de red, suficientemente fina para dejar ver el balón.
    for x in (-3.3, -2.2, -1.1, 0.0, 1.1, 2.2, 3.3):
        box(f"red fondo vertical {x:+.1f}", (x, 1.2, -2.0), (0.016, 1.14, 0.016), net=True)
    for y in (0.25, 0.65, 1.05, 1.45, 1.85, 2.25):
        box(f"red fondo horizontal {y:.2f}", (0.0, y, -2.0), (3.60, 0.016, 0.016), net=True)
    return children


def fix_goals(doc: dict) -> None:
    nodes = doc["nodes"]
    left = node_index(doc, "Control | portería gol")
    ball = node_index(doc, "Balon_Gol")
    frame_mesh = nodes[node_index(doc, "Cube")]["mesh"]

    # Reutiliza la malla cúbica existente, con el material de red del GLB.
    net_mesh = len(doc["meshes"])
    net = copy.deepcopy(doc["meshes"][frame_mesh])
    net["name"] = "Red | hilo blanco"
    for primitive in net["primitives"]:
        # `Plane` referencia un mesh; el material de red está en su primer primitive.
        plane_mesh = nodes[node_index(doc, "Plane")]["mesh"]
        primitive["material"] = doc["meshes"][plane_mesh]["primitives"][0]["material"]
    doc["meshes"].append(net)

    left_node = nodes[left]
    left_node["translation"] = [-52.5, 0.0, 0.0]
    left_node["rotation"] = [0.0, math.sqrt(0.5), 0.0, math.sqrt(0.5)]
    left_node.pop("scale", None)
    left_node["children"] = [ball] + goal_children(doc, "Portería izquierda", frame_mesh, net_mesh)

    right_children = goal_children(doc, "Portería derecha", frame_mesh, net_mesh)
    right = {
        "name": "Control | portería opuesta",
        "translation": [52.5, 0.0, 0.0],
        "rotation": [0.0, -math.sqrt(0.5), 0.0, math.sqrt(0.5)],
        "children": right_children,
    }
    doc["nodes"].append(right)
    right_idx = len(doc["nodes"]) - 1
    scene = doc["scenes"][doc.get("scene", 0)]
    if right_idx not in scene["nodes"]:
        scene["nodes"].append(right_idx)


def fix_field_placements(doc: dict) -> None:
    # Corredor perimetral: el modelo del carrito está modelado en centímetros.
    cart = doc["nodes"][node_index(doc, "Control | carrito de alimentos")]
    cart["translation"] = [0.15, 0.0, -42.1]
    cart["scale"] = [0.05, 0.05, 0.05]

    # El vehículo de emergencia se ubica junto al acceso, fuera del terreno.
    emergency = doc["nodes"][node_index(doc, "Control | emergencias")]
    emergency["translation"] = [70.0, 0.0, -60.0]

    # Árbitro dentro del área de juego, cerca de la acción y sin pisar la línea.
    referee = doc["nodes"][node_index(doc, "Control | árbitro")]
    referee["translation"] = [-42.0, 0.0, 5.0]

    corners = {
        "Control | esquina": (-52.5, 0.0, 34.0),
        "Control | esquina 2": (52.5, 0.0, 34.0),
        "Control | esquina 3": (-52.5, 0.0, -34.0),
        "Control | esquina 4": (52.5, 0.0, -34.0),
    }
    for name, pos in corners.items():
        set_position(doc["nodes"][node_index(doc, name)], pos)


def fix_lighting_towers(doc: dict) -> None:
    # Reemplaza torres exportadas acostadas por mástiles verticales en el perímetro.
    mesh = doc["nodes"][node_index(doc, "Cube")]["mesh"]
    towers = [
        ("Control | torre 1", -82.0, 52.0),
        ("Control | torre 2", -82.0, -52.0),
        ("Control | torre 3", 82.0, 52.0),
        ("Control | torre 4", 82.0, -52.0),
    ]
    for k, (name, x, z) in enumerate(towers, 1):
        root = doc["nodes"][node_index(doc, name)]
        root["translation"] = [x, 0.0, z]
        root.pop("rotation", None)
        root.pop("scale", None)
        children = [
            add_box(doc, f"Torre {k} | mástil", mesh, (0.0, 11.0, 0.0), (0.24, 11.0, 0.24)),
            add_box(doc, f"Torre {k} | soporte superior", mesh, (0.0, 22.0, 0.0), (0.75, 0.25, 0.48)),
            add_box(doc, f"Torre {k} | brazo", mesh, (0.0, 21.0, 0.0), (1.25, 0.10, 0.10)),
        ]
        for lamp in range(5):
            lx = -0.8 + lamp * 0.4
            children.append(add_box(doc, f"Torre {k} | luminaria {lamp + 1}", mesh,
                                    (lx, 22.0, -0.32), (0.17, 0.24, 0.08)))
        root["children"] = children

    for i in range(4):
        name = f"Reflector {i + 1} | encendido gradual"
        idx = node_index(doc, name)
        node = doc["nodes"][idx]
        x, z = towers[i][1], towers[i][2]
        node["translation"] = [x, 22.0, z]


def main() -> None:
    doc, binary, chunks = read_glb(GLB)
    fix_player_path(doc, binary)
    fix_field_placements(doc)
    fix_goals(doc)
    fix_lighting_towers(doc)
    write_glb(GLB, doc, binary, chunks)
    print(f"Escena ajustada: {GLB}")
    print(f"Nodos: {len(doc['nodes'])}; porterías: 2; banderines: 4; torres: 4")


if __name__ == "__main__":
    main()
