#version 330 core
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUv;
layout(location=3) in ivec4 aBoneIds;
layout(location=4) in vec4 aBoneWeights;
const int MAX_BONES=128;
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;
uniform mat4 uLightSpace;
uniform mat4 uBones[MAX_BONES];
uniform int uHasBones;
out vec3 vWorldPos;
out vec3 vNormal;
out vec2 vUv;
out vec4 vLightPos;
void main(){
    mat4 skin=mat4(1.0);
    if(uHasBones!=0){skin=mat4(0.0);float sumWeights=0.0;for(int i=0;i<4;++i){int id=aBoneIds[i];float w=aBoneWeights[i];if(id>=0&&id<MAX_BONES&&w>0.0){skin+=uBones[id]*w;sumWeights+=w;}}if(sumWeights<0.001)skin=mat4(1.0);}
    vec4 world=uModel*skin*vec4(aPosition,1.0);vWorldPos=world.xyz;vNormal=mat3(transpose(inverse(uModel*skin)))*aNormal;vUv=aUv;vLightPos=uLightSpace*world;gl_Position=uProjection*uView*world;
}
