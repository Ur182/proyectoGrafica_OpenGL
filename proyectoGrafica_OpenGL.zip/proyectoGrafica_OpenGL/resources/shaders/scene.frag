#version 330 core
struct Material{vec3 color;float alpha;};
uniform Material uMaterial;
uniform sampler2D uTexture;
uniform sampler2D uShadowMap;
uniform int uHasTexture;
uniform vec3 uCameraPos,uSunDir,uSunColor,uAmbient;
uniform int uNight,uLightsOn;
uniform vec3 uSpotPos[4],uSpotDir[4];
in vec3 vWorldPos,vNormal;
in vec2 vUv;
in vec4 vLightPos;
out vec4 FragColor;
float shadowAmount(vec3 n){
    vec3 p=vLightPos.xyz/vLightPos.w;p=p*0.5+0.5;
    if(p.z>1.0||p.x<0.0||p.x>1.0||p.y<0.0||p.y>1.0)return 0.0;
    float bias=max(0.0012*(1.0-dot(n,normalize(-uSunDir))),0.00035);
    vec2 texel=1.0/vec2(textureSize(uShadowMap,0));float s=0.0;
    for(int x=-1;x<=1;++x)for(int y=-1;y<=1;++y){float z=texture(uShadowMap,p.xy+vec2(x,y)*texel).r;s+=p.z-bias>z?1.0:0.0;}
    return s/9.0;
}
void main(){
    vec4 texel=uHasTexture!=0?texture(uTexture,vUv):vec4(1.0);vec3 albedo=texel.rgb*uMaterial.color;vec3 n=normalize(vNormal);
    float sun=max(dot(n,normalize(-uSunDir)),0.0);float shadow=shadowAmount(n);vec3 lit=albedo*(uAmbient+sun*uSunColor*(1.0-shadow));
    if(uNight!=0&&uLightsOn!=0)for(int i=0;i<4;++i){vec3 toLight=uSpotPos[i]-vWorldPos;float d=length(toLight);vec3 l=normalize(toLight);float cone=smoothstep(0.72,0.88,dot(normalize(-l),normalize(uSpotDir[i])));float att=1.0/(1.0+0.002*d*d);lit+=albedo*vec3(1.0,0.82,0.55)*max(dot(n,l),0.0)*cone*att*2.2;}
    FragColor=vec4(lit,texel.a*uMaterial.alpha);
}
